import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { add } from 'three/examples/jsm/nodes/Nodes.js';

// Get the container element
const container = document.getElementById('threedee');
// Initialize scene, camera, renderer

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setClearColor(0, 0); 
container.appendChild(renderer.domElement);

// Add lights
var MainLighty = new THREE.DirectionalLight(0xffffff, 1);
var BackLighty = new THREE.DirectionalLight(0x114488, 1);

MainLighty.position.set(5, 5, 5); 
BackLighty.position.set(-5, 5, 0); 

scene.add(MainLighty);
scene.add(BackLighty);

camera.position.z = 5;

// Variables to store mouse position
export let mouse = new THREE.Vector2();
export let targetObject;

// Load the GLTF model
const loader = new GLTFLoader();
loader.load('box.gltf', function(gltf) {
  scene.add(gltf.scene);

  // Find the specific object you want to animate
  targetObject = gltf.scene.getObjectByName('heyswitch');

  // Ensure the object was found
  if (!targetObject) {
    console.error('Object not found');
  }
}, undefined, function(error) {
  console.error(error);
});

// Add raycaster for hover and click detection
export const raycaster = new THREE.Raycaster();

// Update mouse position on move
function onMouseMove(event) {
  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
}

document.addEventListener('mousemove', onMouseMove, false);

// Handle window resize
window.addEventListener('resize', () => {
  const width = window.innerWidth;
  const height = window.innerHeight;

  renderer.setSize(width, height);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
});

window.addEventListener('click', onMouseClick, false);

var lightswitch = 50;

export function switchyOff(object) {
  const duration = 100; // rotation duration in ms
  var targetRotation = object.rotation.z - Math.PI / 360 * lightswitch; // rotate 360 degrees
  const startTime = performance.now();

  // If the light is currently ON (Default)
  if (lightswitch === 50) { 
    MainLighty.intensity = 0.1; // Adjust intensity
    lightswitch = -50;

    // if the light is off (you turned it off)
  } else {
    lightswitch = 50;
    MainLighty.intensity = 1.0; // Adjust intensity
  }

  function animateRotation() {
    const currentTime = performance.now();
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);

    object.rotation.z = THREE.MathUtils.lerp(object.rotation.z, targetRotation, progress);

    if (progress < 1) {
      requestAnimationFrame(animateRotation);
    }
  }

  animateRotation();
}

// Render loop
function animate() {
  requestAnimationFrame(animate);

  raycaster.setFromCamera(mouse, camera);
  const intersects = raycaster.intersectObjects(scene.children, true);
  const isIntersected = intersects.length > 0 && (intersects[0].object === targetObject || targetObject.parent === intersects[0].object);
  document.body.style.cursor = isIntersected ? 'pointer' : 'default';
  renderer.render(scene, camera);
}

function onMouseClick(event) {
  // Convert the mouse position to normalized device coordinates (-1 to +1)
  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

  // Update the raycaster with the camera and mouse position
  raycaster.setFromCamera(mouse, camera);

  // Calculate objects intersecting the ray
  const intersects = raycaster.intersectObjects(scene.children, true);
  if (intersects.length > 0) {
    // Check if the intersected object is the targetObject or a child of it
    for (let i = 0; i < intersects.length; i++) {
      if (intersects[i].object === targetObject || targetObject.parent === intersects[i].object) {
        switchyOff(targetObject);
        break;
      }
    }
  }
}


animate();
// END